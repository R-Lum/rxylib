#' xylib wrapper
#'
#' @name rxylib-package
#' @aliases rxylib-package rxylib
#' @docType package
#' @author Sebastian Kreutzer
#'
#' @keywords package
#' @useDynLib rxylib, .registration = TRUE
NULL
