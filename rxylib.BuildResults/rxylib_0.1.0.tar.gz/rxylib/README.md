# rxylib
xylib wrapper for R 

See original project [http://xylib.sourceforge.net](http://xylib.sourceforge.net)

**NOTE: THE LIBRARY IS CURRENTLY NOT COMPLETE!**
