context("read_xyData")

test_that("Test various examples", {
  testthat::skip_on_cran()

})
