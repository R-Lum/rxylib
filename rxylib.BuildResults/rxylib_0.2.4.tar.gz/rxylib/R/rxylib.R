#' @title Import XY-Data into R
#'
#' \if{html}{
#' \figure{rxylib.png}{options: width="50px"}\cr
#' }
#'
#' @description
#' Provides access to the 'xylib' C library for to import xy
#' data from powder diffraction, spectroscopy and other experimental methods, like gamma-ray spectrometry.
#'
#' \tabular{ll}{ Package: \tab rxylib\cr Type: \tab Package\cr Version:
#' \tab 0.2.4 \cr Date: \tab 2019-XX-XX \cr License: \tab GPL-3 | LGPL-2.1 (for the C++ library 'xylib') \cr }
#'
#' @details
#'
#' **Funding**
#'
#' Between 2017-2019, the work of Sebastian Kreutzer as maintainer of the package was supported
#' by LabEx LaScArBxSK (ANR - n. ANR-10-LABX-52).
#'
#' Supported data formats
#'
#' @name rxylib-package
#' @aliases rxylib-package rxylib
#' @docType package
#' @author Sebastian Kreutzer, IRAMAT-CRP2A, Université Bordeaux Montaigne (France), Johannes Friedrich (University of Bayreuth, Germany), RLum Team (family support), Marcin Wojdyr (maintainer and author of the C++ library `xylib`), Peng Zhang (author of the C++ library `xylib`)
#'
#' @keywords package
#' @import utils methods
#' @importFrom graphics plot
#' @importFrom Rcpp evalCpp
#' @useDynLib rxylib, .registration=TRUE
NULL
