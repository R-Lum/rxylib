## rxylib 0.2.2 (Release date: 2019-04-11)

* Update to newest 'xylib' version
* Modify example in convert_xy2TKA() to avoid CRAN problems
* Add README.md
* Switch to NEWS.md

## rxylib 0.2.1 (Release date: 2017-12-20)


* Add function convert_xy2TKA()
* Reduction of the library size by stripping debug entries

## rxylib 0.2.0 (Release date: 2017-07-28)

* Add full support for file format metadata
* Add full support for column names (R like set to V1 and V2 if not provided otherwise)
* Add full support for block names
* Add S3-methods for `plot` and `print`
* Add new example dataset for a TL spectrum (XSYG-file format) and a ChiPlot (chi-file format)
* Add internal function `get_version` to return the 'xylib' version number
* Unfortunately the table with the supported file format got missing during the last update
round ... again added

## rxylib 0.1.1 (Release date: 2017-07-05)

* Correct for CRAN error on Solaris platform
* Remove import of package 'stringr'
* Correct faulty set value for multibock (fixed by Johannes Friedrich)
* Fix minor issue for case the data format is not obvious
* Update to newest 'xylib' library version

## rxylib 0.1.0 (Release date: 2017-06-30)

* Initial version
